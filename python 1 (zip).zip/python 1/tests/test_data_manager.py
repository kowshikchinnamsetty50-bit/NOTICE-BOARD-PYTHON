import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from modules.data_manager import NoticeDataManager

dm = NoticeDataManager()
notices = dm.get_all_notices()
m = dm.get_dashboard_metrics(notices)

print("--- Data Manager Verification ---")
print(f"Total notices loaded: {m['total']}")
print(f"Active notices: {m['active']}")
print(f"Expired notices: {m['expired']}")
print(f"Upcoming notices: {m['upcoming']}")
print(f"Expiring soon: {m['expiring_soon_count']}")
print(f"High priority active: {m['high_priority_active_count']}")

assert m['total'] >= 30, f"Expected at least 30 notices, got {m['total']}"
assert m['active'] > 0, "Expected active notices"
assert m['expired'] > 0, "Expected expired notices"
assert m['upcoming'] > 0, "Expected upcoming notices"

# Test add notice
res, msg, item = dm.add_notice({
    "title": "Unit Test Campus Hackathon 2026",
    "category": "Academics",
    "description": "This is a detailed unit test description for the notice board organizer application.",
    "published_date": "2026-11-20",
    "expiry_date": "2026-12-05",
    "priority": "High",
    "audience": "All Students",
    "department": "Computer Science"
})
assert res is True, f"Add notice failed: {msg}"
print(f"Added notice: {item['id']} - {item['title']}")

# Test update notice
res_up, msg_up, item_up = dm.update_notice(item['id'], {
    "title": "Updated Campus Hackathon 2026",
    "category": "Academics",
    "description": "Updated description with more than 10 characters.",
    "published_date": "2026-11-20",
    "expiry_date": "2026-12-06",
    "priority": "Medium",
    "audience": "All Students",
    "department": "Computer Science"
})
assert res_up is True, f"Update notice failed: {msg_up}"
print(f"Updated notice: {item_up['id']} - {item_up['title']}")

# Test delete notice
res_del, msg_del = dm.delete_notice(item['id'])
assert res_del is True, f"Delete notice failed: {msg_del}"
print(f"Deleted notice: {item['id']}")

print("All tests passed successfully!")
