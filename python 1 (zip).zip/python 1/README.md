# 🏛️ CampusPulse — College Notice Board Organizer

A clean, modern, and beginner-friendly Python web application built with **Streamlit** to help college students, faculty, and administrative staff manage, publish, search, and track campus notices seamlessly.

---

## 🌟 Key Features

1. **📊 Interactive Analytics Dashboard**
   - **Live Metric Cards:** Total notices, active notices, upcoming notices, and expired notices.
   - **Urgent Expiration Alerts:** Automatically alerts users of announcements expiring within the next 3 days.
   - **Interactive Charts:** Category distribution and status breakdown visual charts powered by Altair.
   - **Priority Highlights:** Direct access to high-priority active notices and latest publications.

2. **🤖 Smart Automatic Status Detection**
   - Automatically determines whether a notice is **Active**, **Upcoming**, or **Expired** by evaluating dates against the current date:
     - 🟢 **Active:** `Published Date <= Today <= Expiry Date` (currently ongoing/actionable).
     - 🔵 **Upcoming:** `Published Date > Today` (scheduled for future release).
     - ⚪ **Expired:** `Expiry Date < Today` (past deadline, preserved for historical records).
   - Dynamically calculates remaining days or elapsed days (e.g., *"Expires in 3 days"*, *"Starts in 5 days"*, *"Expired 2 days ago"*).

3. **📋 Comprehensive Search & Filtering**
   - **Real-time Keyword Search:** Instant search across notice title, description, issuing department, and notice ID.
   - **Multi-Facet Filters:** Filter by category, status, priority level, and target audience.
   - **Flexible Sorting:** Sort by published date (newest/oldest), expiry date (earliest/latest), title (A-Z), or priority.
   - **View Toggle:** Switch between a card layout and an interactive tabular data view.

4. **➕ Easy Notice Publishing with Input Validation**
   - Simple, intuitive form to add notices with title, category, priority, target audience, department, and dates.
   - **Strict Input Validation:** Prevents empty titles, enforces minimum description lengths, validates format, and guarantees that expiry dates cannot precede publication dates.
   - **Live Preview:** See exactly how the notice card will appear before finalizing.

5. **✏️ Notice Management (Edit & Delete)**
   - Pre-populated edit forms to update any details, dates, or priority levels of published notices.
   - Safe deletion flow with mandatory confirmation to prevent accidental data loss.

6. **📑 Reports & One-Click Export**
   - Generate summary reports and category/department cross-tabulations.
   - **Export to CSV:** Download all notices as `.csv` for Excel or spreadsheet analysis.
   - **Export to JSON:** Download full structured JSON archive for backups or API integration.

7. **📦 Preloaded Realistic Sample Data**
   - Includes **32 realistic college notices** covering Academics, Examinations, Placements, Cultural Fests, Sports, Scholarships, Hostels, and Administration.
   - Dynamically anchored around the current date, guaranteeing a balanced distribution of Active, Expired, and Upcoming notices whenever the app is launched.

---

## 📂 Project Structure

```text
notice-board-organizer/
├── app.py                     # Main Streamlit application entry point
├── config.py                  # System configuration, constants, categories, and colors
├── requirements.txt           # Project dependencies
├── README.md                  # Complete documentation and user guide
├── run.bat                    # One-click Windows batch launcher
├── run.ps1                    # One-click Windows PowerShell launcher
├── data/
│   ├── notices.json           # Primary local database (JSON format)
│   └── notices.csv            # Auto-synchronized CSV copy for external tools
└── modules/
    ├── __init__.py            # Python package initialization
    ├── data_manager.py        # Storage handling, CRUD operations, validation & auto-status logic
    └── ui_components.py       # Custom CSS styling, badges, metric cards & chart helpers
```

---

## 🛠️ Technology Stack

- **Python 3.10+ / 3.14**
- **Streamlit** (Web Application Framework)
- **Pandas** (Data analysis, tabular viewing, and CSV processing)
- **Altair** (Declarative statistical data visualization)
- **JSON & CSV** (Lightweight, zero-configuration local persistence)

---

## 🚀 Getting Started

### 1. Clone or Open the Project
Open terminal or command prompt inside the project folder:
```bash
cd "path/to/Notice Board Organizer"
```

### 2. Install Dependencies
Install all required packages using `pip`:
```bash
pip install -r requirements.txt
```

### 3. Run the Application
Launch the Streamlit app with:
```bash
streamlit run app.py
```

*Alternative (if `streamlit` is not directly on your system PATH):*
```bash
python -m streamlit run app.py
```
*Or on Windows, simply double-click `run.bat` or run `./run.ps1` in PowerShell.*

---

## 🧭 Using the Application

| Page | Description |
| :--- | :--- |
| **📊 Dashboard** | High-level metrics, expiration alerts, visual category/status charts, and top notices. |
| **📋 Browse & Search** | Search through all notices, apply multi-filters, and switch between Card and Table modes. |
| **➕ Add New Notice** | Publish new announcements with real-time input validation and live card preview. |
| **✏️ Edit & Manage** | Select any notice to update its content or safely delete it with confirmation. |
| **📑 Reports & Export** | View summary matrices and download notice archives as CSV or JSON files. |
| **ℹ️ User Guide & About** | Detailed explanation of date rules, data schemas, and a demo reset button. |

---

## 📋 Notice Data Fields

Each notice record contains the following fields:

| Field | Type | Description |
| :--- | :--- | :--- |
| `id` | String | Unique institutional identifier (e.g. `NOT-001`) |
| `title` | String | Clear headline of the announcement |
| `category` | String | One of 8 standard categories (Academics, Examinations, Placements, etc.) |
| `description` | String | Comprehensive notice text, instructions, and details |
| `published_date` | Date (YYYY-MM-DD) | Date when the announcement becomes effective |
| `expiry_date` | Date (YYYY-MM-DD) | Date after which the notice is considered expired |
| `priority` | String | Urgency level: `High`, `Medium`, or `Low` |
| `audience` | String | Target recipient group (e.g. `All Students`, `Final Year Students`) |
| `department` | String | Issuing department or administrative office |
| `status` | String | Automatically determined: `Active`, `Upcoming`, or `Expired` |
| `time_label` | String | Human-readable relative time (e.g., *"Expires in 5 days"*) |

---

## 💡 Beginner-Friendly Tips & Code Architecture

- **Modular Separation of Concerns:**
  - `config.py` isolates all constants, categories, and theme colors so they can be modified in one place without touching core logic.
  - `modules/data_manager.py` contains all database and business logic, keeping `app.py` clean and focused on user experience.
  - `modules/ui_components.py` encapsulates custom CSS and reusable design widgets.
- **Zero Database Server Setup:**
  - Uses standard JSON and CSV files stored directly in `data/`, making it run out-of-the-box on any computer without configuring PostgreSQL, MySQL, or SQLite.
- **Self-Healing Sample Data:**
  - If `data/notices.json` is missing or cleared, the application will automatically initialize itself with 32 realistic college notices.

---

## 📄 License
This project is open-source and free to use for educational, college campus, and personal projects.
