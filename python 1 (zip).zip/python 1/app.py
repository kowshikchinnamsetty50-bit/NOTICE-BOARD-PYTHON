"""
CampusPulse: College Notice Board Organizer
Main Application Entry Point built with Streamlit.
"""

from datetime import date, datetime, timedelta
import pandas as pd
import streamlit as st

from config import (
    APP_SUBTITLE,
    APP_TITLE,
    AUDIENCES,
    CATEGORIES,
    CATEGORY_ICONS,
    COLLEGE_NAME,
    PRIORITIES,
    PRIORITY_BADGES,
    STATUS_ACTIVE,
    STATUS_EXPIRED,
    STATUS_OPTIONS,
    STATUS_UPCOMING,
)
from modules.data_manager import NoticeDataManager, compute_notice_status
from modules.ui_components import (
    inject_custom_css,
    render_category_chart,
    render_dashboard_metrics,
    render_notice_card_html,
    render_portal_header,
    render_priority_badge_html,
    render_status_badge_html,
    render_status_chart,
)

# Set Streamlit Page Configuration
st.set_page_config(
    page_title=f"{APP_TITLE} | {APP_SUBTITLE}",
    page_icon="🏛️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Apply Custom CSS
inject_custom_css()

# Initialize Data Manager
@st.cache_resource
def get_data_manager() -> NoticeDataManager:
    return NoticeDataManager()

dm = get_data_manager()


def sidebar_navigation() -> str:
    """Render the sidebar branding and navigation menu."""
    st.sidebar.markdown(
        f"""
        <div style="text-align: center; padding: 12px 0 16px 0; border-bottom: 1px solid #E2E8F0;">
            <div style="font-size: 38px; line-height: 1;">🏛️</div>
            <h2 style="margin: 8px 0 2px 0; font-size: 20px; font-weight: 800; color: #1E3A8A;">{APP_TITLE}</h2>
            <p style="margin: 0; font-size: 11px; color: #64748B; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Campus Notice Board</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.sidebar.markdown("### 📌 Navigation")
    menu_options = [
        "📊 Dashboard",
        "📋 Browse & Search Notices",
        "➕ Add New Notice",
        "✏️ Edit & Manage Notices",
        "📑 Reports & Export",
        "ℹ️ User Guide & About",
    ]

    # Preserve selected page in query param or session state if needed
    if "current_page" not in st.session_state:
        st.session_state["current_page"] = menu_options[0]

    selected = st.sidebar.radio(
        "Go to page:",
        options=menu_options,
        index=menu_options.index(st.session_state["current_page"])
        if st.session_state["current_page"] in menu_options
        else 0,
        label_visibility="collapsed",
    )
    st.session_state["current_page"] = selected

    # Quick summary in sidebar
    metrics = dm.get_dashboard_metrics()
    st.sidebar.markdown("---")
    st.sidebar.markdown("#### ⚡ Quick Pulse")
    col_a, col_b = st.sidebar.columns(2)
    col_a.metric("Active", metrics["active"])
    col_b.metric("Upcoming", metrics["upcoming"])

    st.sidebar.markdown(
        f"""
        <div class="sidebar-card">
            <strong>🏫 {COLLEGE_NAME}</strong><br/>
            Academic Session: 2026–2027<br/>
            Local Storage: <code>JSON & CSV</code><br/>
            <span style="color: #059669; font-weight: 600;">● System Online</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    return selected


# ==============================================================================
# PAGE 1: DASHBOARD
# ==============================================================================
def page_dashboard() -> None:
    render_portal_header()
    notices = dm.get_all_notices()
    metrics = dm.get_dashboard_metrics(notices)

    # 1. Metric Cards
    render_dashboard_metrics(metrics)
    st.write("")

    # 2. Urgent Attention Alert (Notices expiring in <= 3 days)
    expiring = metrics["expiring_soon"]
    if expiring:
        st.markdown(
            f"""
            <div class="alert-box">
                <strong>⚠️ Notice Expiration Alert:</strong>
                There {'is' if len(expiring) == 1 else 'are'} <strong>{len(expiring)} active notice{'s' if len(expiring) != 1 else ''}</strong>
                expiring within the next 3 days. Please review and take required action before deadlines lapse!
            </div>
            """,
            unsafe_allow_html=True,
        )

    # 3. Visual Charts Section
    col_chart1, col_chart2 = st.columns([1.5, 1])
    with col_chart1:
        st.markdown("#### 📊 Notices by Category")
        render_category_chart(notices)

    with col_chart2:
        st.markdown("#### 🎯 Status Breakdown")
        render_status_chart(notices)

    st.markdown("---")

    # 4. Featured / High-Priority Active Notices
    st.markdown("#### 🔥 High Priority Active Announcements")
    high_priority = metrics["high_priority_active"]
    if high_priority:
        for n in high_priority[:4]:
            st.markdown(render_notice_card_html(n), unsafe_allow_html=True)
    else:
        st.info("No high-priority active notices at this moment.")

    # 5. Quick Links & Recent Feed
    st.markdown("---")
    st.markdown("#### 🕒 Latest Published Notices")
    recent = sorted(notices, key=lambda x: x.get("published_date", ""), reverse=True)[:3]
    for n in recent:
        st.markdown(render_notice_card_html(n), unsafe_allow_html=True)


# ==============================================================================
# PAGE 2: BROWSE & SEARCH NOTICES
# ==============================================================================
def page_browse_notices() -> None:
    st.markdown("## 📋 Campus Notice Board")
    st.markdown("Search, filter, and view all college announcements.")

    notices = dm.get_all_notices()

    # Search & Filter Controls
    search_col, sort_col = st.columns([3, 1.5])
    with search_col:
        search_query = st.text_input(
            "🔍 Search notices by keyword, title, ID, or department:",
            placeholder="e.g. Exam, Placement, Hackathon, Library, NOT-001...",
        )
    with sort_col:
        sort_by = st.selectbox(
            "Sort by:",
            [
                "Published Date (Newest)",
                "Published Date (Oldest)",
                "Expiry Date (Earliest)",
                "Expiry Date (Latest)",
                "Priority (High to Low)",
                "Title (A-Z)",
            ],
        )

    # Multi-facet filters
    with st.expander("🎯 Filter by Category, Status, Priority & Audience", expanded=False):
        f_col1, f_col2, f_col3, f_col4 = st.columns(4)
        with f_col1:
            cat_filter = st.selectbox("Category:", ["All"] + CATEGORIES)
        with f_col2:
            status_filter = st.selectbox("Status:", ["All"] + STATUS_OPTIONS)
        with f_col3:
            priority_filter = st.selectbox("Priority:", ["All"] + PRIORITIES)
        with f_col4:
            audience_filter = st.selectbox("Audience:", ["All"] + AUDIENCES)

    # Apply filters
    filtered = dm.filter_notices(
        notices=notices,
        search_query=search_query,
        category=cat_filter,
        status=status_filter,
        priority=priority_filter,
        audience=audience_filter,
        sort_by=sort_by,
    )

    # View layout selector and count badge
    c_left, c_right = st.columns([3, 1])
    with c_left:
        st.markdown(
            f"Showing **{len(filtered)}** of **{len(notices)}** notices "
            + (f"matching criteria" if len(filtered) != len(notices) else "")
        )
    with c_right:
        view_mode = st.radio("Display Mode:", ["Card View", "Table View"], horizontal=True)

    if not filtered:
        st.warning("No notices found matching your search and filter criteria. Try adjusting your filters.")
        return

    # Render results
    if view_mode == "Card View":
        for notice in filtered:
            st.markdown(render_notice_card_html(notice), unsafe_allow_html=True)
    else:
        # Table View
        df = dm.get_dataframe(filtered)
        display_df = df[
            [
                "id",
                "title",
                "category",
                "status",
                "priority",
                "audience",
                "published_date",
                "expiry_date",
                "time_label",
                "department",
            ]
        ].copy()
        display_df.rename(
            columns={
                "id": "Notice ID",
                "title": "Title",
                "category": "Category",
                "status": "Status",
                "priority": "Priority",
                "audience": "Target Audience",
                "published_date": "Published",
                "expiry_date": "Expires",
                "time_label": "Timeline",
                "department": "Department",
            },
            inplace=True,
        )
        st.dataframe(
            display_df,
            use_container_width=True,
            hide_index=True,
            column_config={
                "Status": st.column_config.TextColumn(
                    "Status",
                    help="Automatic status based on date",
                ),
            },
        )


# ==============================================================================
# PAGE 3: ADD NEW NOTICE
# ==============================================================================
def page_add_notice() -> None:
    st.markdown("## ➕ Publish New Notice")
    st.markdown("Fill out the form below to broadcast an official announcement to students and faculty.")

    today = date.today()

    with st.form("add_notice_form", clear_on_submit=False):
        st.markdown("#### 1. Basic Notice Information")
        title = st.text_input(
            "Notice Title *",
            placeholder="e.g. Schedule for Mid-Term Examination 2026",
            help="Enter a clear, descriptive title between 3 and 120 characters.",
        )

        col1, col2 = st.columns(2)
        with col1:
            category = st.selectbox(
                "Notice Category *",
                CATEGORIES,
                format_func=lambda x: f"{CATEGORY_ICONS.get(x, '📌')} {x}",
            )
        with col2:
            priority = st.selectbox("Priority Level *", PRIORITIES, index=1)

        col3, col4 = st.columns(2)
        with col3:
            audience = st.selectbox("Target Audience *", AUDIENCES)
        with col4:
            department = st.text_input(
                "Issuing Department / Office *",
                value="Dean of Academic Affairs",
                help="The department or office authorizing this announcement.",
            )

        st.markdown("#### 2. Notice Dates (Controls Automatic Status)")
        st.caption(
            "💡 The system automatically determines whether this notice is **Active**, **Upcoming**, or **Expired** based on these dates relative to today."
        )

        col_d1, col_d2 = st.columns(2)
        with col_d1:
            published_date = st.date_input(
                "Published Date *",
                value=today,
                help="Date when the notice becomes visible or takes effect.",
            )
        with col_d2:
            expiry_date = st.date_input(
                "Expiry Date (Deadline) *",
                value=today + timedelta(days=14),
                help="Date when the notice or application deadline concludes.",
            )

        st.markdown("#### 3. Notice Content")
        description = st.text_area(
            "Detailed Description / Announcement Body *",
            placeholder="Provide comprehensive details, instructions, links, eligibility criteria, venue, and relevant contacts...",
            height=160,
            help="Detailed notice text (minimum 10 characters).",
        )

        submitted = st.form_submit_button("🚀 Publish Notice to Board", use_container_width=True)

    if submitted:
        new_data = {
            "title": title,
            "category": category,
            "description": description,
            "published_date": published_date,
            "expiry_date": expiry_date,
            "priority": priority,
            "audience": audience,
            "department": department,
        }

        success, message, created_item = dm.add_notice(new_data)
        if success and created_item:
            st.success(f"🎉 {message}")
            st.markdown("#### 👁️ Live Preview of Published Notice:")
            st.markdown(render_notice_card_html(created_item), unsafe_allow_html=True)
        else:
            st.error(f"❌ Could not publish notice: {message}")


# ==============================================================================
# PAGE 4: EDIT & MANAGE NOTICES
# ==============================================================================
def page_edit_delete_notice() -> None:
    st.markdown("## ✏️ Edit & Manage Notices")
    st.markdown("Update existing announcements or securely remove outdated records.")

    notices = dm.get_all_notices()
    if not notices:
        st.info("No notices available to edit or delete.")
        return

    # Select a notice to manage
    notice_options = {f"{n['id']} - {n['title']} ({n['status']})": n['id'] for n in notices}
    selected_label = st.selectbox(
        "Select Notice to Manage:",
        options=list(notice_options.keys()),
        help="Search or select a notice by ID, title, or status.",
    )
    selected_id = notice_options[selected_label]
    notice = dm.get_notice_by_id(selected_id)

    if not notice:
        st.error("Selected notice could not be retrieved.")
        return

    tab_edit, tab_delete = st.tabs(["✏️ Edit Notice Details", "🗑️ Delete Notice"])

    # --- TAB 1: EDIT NOTICE ---
    with tab_edit:
        st.markdown(f"### Editing **{notice['id']}**: {notice['title']}")

        # Parse stored dates
        try:
            pub_default = datetime.strptime(notice["published_date"], "%Y-%m-%d").date()
        except Exception:
            pub_default = date.today()

        try:
            exp_default = datetime.strptime(notice["expiry_date"], "%Y-%m-%d").date()
        except Exception:
            exp_default = date.today() + timedelta(days=7)

        with st.form(f"edit_form_{notice['id']}"):
            new_title = st.text_input("Notice Title *", value=notice.get("title", ""))

            col1, col2 = st.columns(2)
            with col1:
                cat_idx = CATEGORIES.index(notice["category"]) if notice.get("category") in CATEGORIES else 0
                new_cat = st.selectbox(
                    "Category *",
                    CATEGORIES,
                    index=cat_idx,
                    format_func=lambda x: f"{CATEGORY_ICONS.get(x, '📌')} {x}",
                )
            with col2:
                pri_idx = PRIORITIES.index(notice["priority"]) if notice.get("priority") in PRIORITIES else 1
                new_pri = st.selectbox("Priority *", PRIORITIES, index=pri_idx)

            col3, col4 = st.columns(2)
            with col3:
                aud_idx = AUDIENCES.index(notice["audience"]) if notice.get("audience") in AUDIENCES else 0
                new_aud = st.selectbox("Target Audience *", AUDIENCES, index=aud_idx)
            with col4:
                new_dept = st.text_input("Department *", value=notice.get("department", "Administration"))

            col_d1, col_d2 = st.columns(2)
            with col_d1:
                new_pub = st.date_input("Published Date *", value=pub_default)
            with col_d2:
                new_exp = st.date_input("Expiry Date *", value=exp_default)

            new_desc = st.text_area("Notice Description *", value=notice.get("description", ""), height=160)

            save_submitted = st.form_submit_button("💾 Save Changes", use_container_width=True)

        if save_submitted:
            update_payload = {
                "title": new_title,
                "category": new_cat,
                "description": new_desc,
                "published_date": new_pub,
                "expiry_date": new_exp,
                "priority": new_pri,
                "audience": new_aud,
                "department": new_dept,
            }
            success, msg, updated_notice = dm.update_notice(notice["id"], update_payload)
            if success and updated_notice:
                st.success(f"✅ {msg}")
                st.markdown("#### Updated Preview:")
                st.markdown(render_notice_card_html(updated_notice), unsafe_allow_html=True)
            else:
                st.error(f"❌ Update failed: {msg}")

    # --- TAB 2: DELETE NOTICE ---
    with tab_delete:
        st.markdown(f"### Danger Zone: Delete **{notice['id']}**")
        st.warning(
            f"You are about to permanently delete **{notice['id']} - {notice['title']}**. This action cannot be undone."
        )

        # Show current notice card
        st.markdown(render_notice_card_html(notice), unsafe_allow_html=True)

        confirm_check = st.checkbox(
            f"I confirm that I want to permanently delete notice {notice['id']}.",
            key=f"del_confirm_{notice['id']}",
        )

        if st.button("🗑️ Permanently Delete Notice", type="primary", disabled=not confirm_check):
            del_success, del_msg = dm.delete_notice(notice["id"])
            if del_success:
                st.success(f"🗑️ {del_msg}")
                st.info("The notice board has been updated. Please refresh or navigate to view current notices.")
            else:
                st.error(f"❌ Error deleting notice: {del_msg}")


# ==============================================================================
# PAGE 5: REPORTS & EXPORT
# ==============================================================================
def page_reports_export() -> None:
    st.markdown("## 📑 Summary Reports & Data Export")
    st.markdown("Generate institutional reports, analytics, and download records in standard CSV or JSON formats.")

    notices = dm.get_all_notices()
    metrics = dm.get_dashboard_metrics(notices)
    df = dm.get_dataframe(notices)

    # 1. High-level Summary Metrics
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Archive Count", metrics["total"])
    col2.metric("Active Announcements", metrics["active"])
    col3.metric("Upcoming Scheduled", metrics["upcoming"])
    col4.metric("Expired / Archived", metrics["expired"])

    st.markdown("---")

    # 2. Export Buttons
    st.markdown("### 📥 Download Notice Data")
    st.markdown("Download all campus notices locally for spreadsheet analysis, institutional archiving, or backup.")

    col_csv, col_json = st.columns(2)
    with col_csv:
        csv_data = dm.export_to_csv_bytes(notices)
        st.download_button(
            label="📄 Download Notices as CSV",
            data=csv_data,
            file_name=f"college_notices_{date.today().strftime('%Y%m%d')}.csv",
            mime="text/csv",
            use_container_width=True,
        )
    with col_json:
        json_data = dm.export_to_json_bytes(notices)
        st.download_button(
            label="📦 Download Notices as JSON",
            data=json_data,
            file_name=f"college_notices_{date.today().strftime('%Y%m%d')}.json",
            mime="application/json",
            use_container_width=True,
        )

    st.markdown("---")

    # 3. Category Summary Matrix
    st.markdown("### 📊 Category & Status Matrix")
    if not df.empty:
        summary_table = pd.crosstab(
            df["category"],
            df["status"],
            margins=True,
            margins_name="Total",
        )
        st.dataframe(summary_table, use_container_width=True)

    # 4. Department Summary
    st.markdown("### 🏛️ Department Activity Report")
    if not df.empty:
        dept_counts = df["department"].value_counts().reset_index()
        dept_counts.columns = ["Department / Issuing Office", "Total Notices Issued"]
        st.dataframe(dept_counts, use_container_width=True, hide_index=True)


# ==============================================================================
# PAGE 6: USER GUIDE & ABOUT
# ==============================================================================
def page_about_guide() -> None:
    st.markdown("## ℹ️ College Notice Board Organizer Guide")
    st.markdown(
        "Welcome to **CampusPulse**, a beginner-friendly, modular notice board system designed for college campuses."
    )

    with st.expander("⏱️ How Does Automatic Status Identification Work?", expanded=True):
        st.markdown(
            """
            The application dynamically compares each notice's **Published Date** and **Expiry Date** against today's date:
            
            1. 🟢 **Active Notice:**
               - Condition: `Published Date <= Today <= Expiry Date`
               - Meaning: The announcement is currently open, ongoing, or within its active window.
            2. 🔵 **Upcoming Notice:**
               - Condition: `Published Date > Today`
               - Meaning: The announcement is scheduled for future release or an upcoming event.
            3. ⚪ **Expired Notice:**
               - Condition: `Expiry Date < Today`
               - Meaning: The deadline, event date, or submission period has passed. It is kept for historical archiving.
            """
        )

    with st.expander("🛡️ Built-in Input Validation Safeguards", expanded=False):
        st.markdown(
            """
            To maintain data integrity across campus departments, the system validates:
            - **Non-empty Title & Body:** Minimum length requirements to prevent blank or meaningless submissions.
            - **Logical Date Constraints:** Expiry date cannot be earlier than the published date.
            - **Format Consistency:** All dates are standardized to ISO YYYY-MM-DD.
            - **Category & Audience:** Enforces recognized institutional categories and target groups.
            """
        )

    with st.expander("💾 Local Persistence (JSON + CSV Dual Sync)", expanded=False):
        st.markdown(
            """
            - **Primary Storage:** `data/notices.json` provides fast, structured data manipulation.
            - **Automatic Synchronization:** Every insert, update, or deletion automatically updates `data/notices.csv`.
            - **Portability:** Can be loaded directly into Excel, Pandas, or database systems without external database servers.
            """
        )

    st.markdown("---")
    st.markdown("### 🔄 Reset Sample Data (Demo Mode)")
    st.info("Demonstrating or grading the project? You can reset the notices back to the initial 32 college samples anytime.")

    if st.button("♻️ Reset to Default Sample Data (32 Notices)", type="secondary"):
        new_samples = dm.reset_to_sample_data()
        st.success(f"Successfully reloaded {len(new_samples)} fresh realistic sample college notices!")
        st.rerun()


# ==============================================================================
# MAIN ROUTING
# ==============================================================================
def main() -> None:
    current_page = sidebar_navigation()

    if current_page == "📊 Dashboard":
        page_dashboard()
    elif current_page == "📋 Browse & Search Notices":
        page_browse_notices()
    elif current_page == "➕ Add New Notice":
        page_add_notice()
    elif current_page == "✏️ Edit & Manage Notices":
        page_edit_delete_notice()
    elif current_page == "📑 Reports & Export":
        page_reports_export()
    elif current_page == "ℹ️ User Guide & About":
        page_about_guide()


if __name__ == "__main__":
    main()
